require("dotenv").config();

const express = require ( "express" );

const fs = require ("fs")
const app = express(); 

const mongoose = require( "mongoose" );

const session = require("express-session")
const passport = require("passport")
const passportLocalMongoose = require("passport-local-mongoose")
require("dotenv").config();

app.use(express.static("public"));

app.use(express.urlencoded({ extended: true})); 

const port = 3009; 

app.use(session({
    secret: process.env.SECRET,
    resave: false,
    saveUninitialized: false
}));

app.use (passport.initialize());
app.use (passport.session());

app.set("view engine", "ejs");

// connect to mongoose on port 27017
mongoose.connect( "mongodb://127.0.0.1:27017/planner", 
                { useNewUrlParser: true, 
                  useUnifiedTopology: true});

            const userSchema = new mongoose.Schema({
                name: String,
                username: String,
                password: String,
                dob: Date
            });
            userSchema.plugin(passportLocalMongoose);
            const User = mongoose.model("User", userSchema);

                passport.use(User.createStrategy());
                passport.serializeUser(User.serializeUser());
                passport.deserializeUser(User.deserializeUser());
app.listen (port, () => {
    console.log (`Server is running on http://localhost:${port}`);
});

app.get("/", (req, res)=>{
    res.sendFile(__dirname + "/index.html");
})

app.get("/signup", (req, res)=>{
    res.sendFile(__dirname + "/signup.html");
});

app.get("/login", (req, res)=>{
    res.sendFile(__dirname + "/login.html");
})

app.get('/logout', (req, res) => {
    res.sendFile(__dirname + "/login.html");
});

app.post('/login', (req, res, next) => {
    passport.authenticate('local', (err, user, info) => {
        if (err) { 
            console.log(err);
            return next(err); 
        }
        if (!user) { 
            console.log(info.message);
            return res.redirect('/login'); 
        }
        req.logIn(user, (err) => {
            if (err) { 
                console.log(err);
                return next(err); 
            }
            req.session.save(() => {
                return res.redirect('/planner');
            });
        });
    })(req, res, next);
});

app.post('/planner', (req, res) => {
    res.render('planner', {username: req.body.username});
});

app.get('/planner', isAuthenticated, (req, res) => {
     res.render('planner', { username: req.user.username});
});

function isAuthenticated(req, res, next) {
    if (req.isAuthenticated()) {
        return next();
    }
    res.redirect('/');
}

app.post('/signup', (req, res) => { 
    User.findOne({ username: req.body.username })
        .then(user => {
            if (user) {
                return res.send('Username already exists');
            }
        
            User.register(new User({ 
                username : req.body.username, 
                password : req.body.password,
                name: req.body.name,
                dob: req.body.dob
            }), req.body.password, (err, user) => {
                if (err) {
                    console.log(err);
                    return res.redirect('/');
                } else {
                    passport.authenticate('local')(req, res, () => {
                        res.redirect('/planner');
                    });
                }
            });
        })
        .catch(err => {
            console.log(err);
            return res.redirect('/');
        });
});
